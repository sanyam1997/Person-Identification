from __future__ import print_function
import numpy as np
from sklearn.ensemble import RandomForestClassifier
import h5py 

f = h5py.File('DataS4.mat','r') 

data1 = f.get('set1') 
label1 = f.get( 'label1' )

tstlabel1 = np.array(label1) 
tstdata1 = np.array(data1) # For converting to numpy array
tstdata1 = tstdata1.transpose( 1 , 0 )
tstlabel1 = tstlabel1.transpose( 1 , 0 )
X_train = tstdata1
y_train = tstlabel1

data2 = f.get('set2') 
label2 = f.get( 'label2' )

tstlabel2 = np.array(label2) 
tstdata2 = np.array(data2) # For converting to numpy array
tstdata2 = tstdata2.transpose( 1 , 0 )
tstlabel2 = tstlabel2.transpose( 1 , 0 )
X_test = tstdata2
y_test = tstlabel2

clf = RandomForestClassifier( n_estimators = 90 )
clf.fit( X_train , y_train )

clf.apply( X_train )
pred = clf.predict(X_train)
prob = clf.predict_proba(X_test)
score = clf.score( X_test , y_test )
mean = score.mean( )

print( mean )
print( pred )
print( prob )
print( score )
