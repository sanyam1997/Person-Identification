from __future__ import print_function
import keras
#import tensorflow as tf
#from tf.contrib import crf
from keras.preprocessing import sequence
import scipy.io as sio
from keras.models import Sequential
from keras.layers import Dense , Embedding , Dropout
from keras.layers import LSTM
from keras.datasets import imdb
from keras.layers import Conv1D , GlobalMaxPooling1D , MaxPooling1D
from itertools import chain
import nltk
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.preprocessing import LabelBinarizer
import sklearn
import pycrfsuite
import tensorflow as tf
#from pystruct.models import ChainCRF
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import cross_val_score
#from pyhcrf import Hcrf
from sklearn.metrics import confusion_matrix
#import os
#os.environ["THEANO_FLAGS"] = "mode=FAST_RUN,device=gpu,lib.cnmem=1,floatX=float32"
#from seq2seq import SimpleSeq2Seq, Seq2Seq, AttentionSeq2Seq
import numpy as np
from sklearn.ensemble import RandomForestClassifier
import scipy.io
from keras.layers import Conv2D, MaxPooling2D
from keras.optimizers import TFOptimizer
#f = scipy.io.loadmat('file.mat')
from keras.layers.convolutional import Conv3D
from keras.layers.convolutional_recurrent import ConvLSTM2D
from keras.layers.normalization import BatchNormalization
from keras.utils.test_utils import keras_test
from sklearn.model_selection import train_test_split
from theano import tensor as T
import theano
import matplotlib.pyplot as plt
import math
import random
from keras.preprocessing import sequence
from keras.utils import np_utils
from keras.models import Sequential
from keras.layers import Dense, Dropout, Activation, Embedding,Flatten
from keras.layers import LSTM, SimpleRNN, GRU , Bidirectional
from keras.layers.normalization import BatchNormalization
from keras.layers import Convolution2D, MaxPooling2D,UpSampling2D, ZeroPadding2D, Lambda , Reshape
#from keras.engine.topology import Merge
import numpy as np
import h5py 
from sklearn.ensemble import RandomForestClassifier
#f = sio.loadmat('dataset.mat')
#lbl = sio.loadmat('labels.mat')
f = h5py.File('DataS5.mat','r') 
#lbl = h5py.File('matlab1.mat' , 'r' )
# For converting to numpy array datasets.mat
#tstlabel=label.transpose(2,0,1)

#data_n = f.get('nom') 
#label_n = f.get( 'lab' )
#tstlabel_n = np.array(label1) 
#tstdata_n = np.array(data1) # For converting to numpy array
#print ( tstdata.shape )
#tstdata_n = tstdata1.transpose( 2 , 1 , 0 )

data1 = f.get('Set1') 
label1 = f.get( 'label3' )
tstlabel1 = np.array(label1) 
tstdata1 = np.array(data1) # For converting to numpy array
#print ( tstdata.shape )
tstdata1 = tstdata1.transpose( 2 , 1 , 0 )
#tstlabel1 = tstlabel1.transpose( 1 , 0 )
#print ( tstdata1.shape )
X_train = tstdata1
y_train = tstlabel1

data2 = f.get('Set2') 
label2 = f.get( 'label4' )
tstlabel2 = np.array(label2) 
tstdata2 = np.array(data2) # For converting to numpy array
#print ( tstdata.shape )
tstdata2 = tstdata2.transpose( 2 , 1 , 0 )
#tstlabel2 = tstlabel2.transpose( 1 , 0 )
#print ( tstdata1.shape )
X_test = tstdata2
y_test = tstlabel2

#total_words = 480 #total number of dataset sequences
#X_train=tstdata[:400 , : , : ]
#X_test=tstdata[ 400: , : , : ]
#tstlabel=tstlabel.transpose(1,0)
#y_train=tstlabel[:,:400]
#y_test=tstlabel[ :, 400: ]

#X_train , X_test , y_train , y_test = train_test_split( tstdata_n , tstlabel_n , test_size = 0.2 , random_state = 42 )
#_train=np.reshape(tstlabel,(tstlabel.shape[0],60))
#_test=np.reshape(tstlabel,(tstlabel.shape[0],60))



#y_train = np_utils.to_categorical(y_train)
# truncate and pad input sequences
max_sequence_length = 120
X_train = sequence.pad_sequences(X_train, maxlen=max_sequence_length)
X_test = sequence.pad_sequences(X_test, maxlen=max_sequence_length)
#model = Hcrf( num_states = 14 , verbosity = 132 , random_seed = 14 )
#model.fit( X_train , y_train )
#pred = model.predict( X_test )
#confusion_matrix( y_test , pred )
# create the model
#embedding_vecor_length = 32
#28,6
#model = Sequential( )
#model.add(Embedding( 2 , 128, input_length=max_sequence_length))
#model.add(Bidirectional(LSTM(64)))
#model.add(Dropout(0.5))
#model.add(Dense(14, activation='sigmoid'))
# initiate RMSprop optimizer
#model = RandomForestClassifier( )
#clf = DecisionTreeClassifier(max_depth=None, min_samples_split=2, random_state=0)


#clf = RandomForestClassifier( n_estimators = 90 )
#clf.fit( X_train , y_train )

#clf.apply( X_train )
#pred = clf.predict(X_train)
#prob = clf.predict_proba(X_test)
#score = clf.score( X_test , y_test )
#scores = cross_val_score(clf, X_train , y_train )
#mean = score.mean( )


#print( mean )
#print( pred )
#print( prob )
#print( score )



#model = ChainCRF( n_features = 14  )
#crf = ChainCRF( ) m
#seq_scores = tf.contrib.crf.crf_sequence_score( [ 10 , 120 , 50 ] , [ 10 , 120 ] , [ 120 ] , [ 50 , 50 ]  )
model = Sequential( )
model.add(LSTM( 64 , return_sequences=True, stateful=True, batch_input_shape=( 15 , 120 , 14 ) ))
model.add( Dropout( 0.2 ) )
model.add(LSTM(20, return_sequences=True, stateful=True))
model.add( Dropout( 0.2 ) )
model.add(LSTM(20, stateful=True))
model.add( Dropout( 0.2 ) )
#tf.contrib.crf.crf_sequence_score( [ 10 , 120 , 50 ] , [ 10 , 120 ] , [ 10 ] , [ 50 , 50 ] )
#model.add( crf )
#model.add(  LSTM( 20 ) )
model.add(Dense(60, activation='sigmoid'))
model.compile(loss='categorical_crossentropy',
              optimizer = 'Adamax',
               metrics=['accuracy'])


#seq.add(ConvLSTM2D(filters=40, kernel_size=(3, 3),
#                   input_shape=( None , 10 , 132 , 14 ),
#                   padding='same', return_sequences=True))
#seq.add(BatchNormalization())

#seq.add(ConvLSTM2D(filters=40, kernel_size=(3, 3),
#                   padding='same', return_sequences=True))
#seq.add(BatchNormalization())

#seq.add(ConvLSTM2D(filters=40, kernel_size=(3, 3),
#                   padding='same', return_sequences=True))
#seq.add(BatchNormalization())

#seq.add(ConvLSTM2D(filters=40, kernel_size=(3, 3),
#                   padding='same', return_sequences=True))
#seq.add(BatchNormalization())
#model = Sequential( )
#model.add(LSTM(120, return_sequences=True, stateful=True, batch_input_shape=( 10 , 120 , 14 )))
#model.add( Dropout( 0.2 ) )
#model.add(LSTM(32, return_sequences=True, stateful=True))
#model.add( Dropout( 0.2 ) )
#model.add(LSTM(32, stateful=True))
#odel.add( Dropout( 0.2 ) )
#model.add(Dense(14, activation='sigmoid'))
#model.add(Conv3D(filters=1, kernel_size=(3, 3, 3),
#               activation='tanh',
#               padding='same', data_format='channels_last'))
#model.compile(loss='categorical_crossentropy',
#              optimizer = 'Adamax',
#              metrics=['accuracy'])



#1model.add(Conv1D(128, 3, activation='tanh', input_shape=( 132, 14 )))
#2model.add(Conv1D(128,3, activation='tanh'))
#3model.add(LSTM(64,input_shape=(132,14),activation='sigmoid', inner_activation='hard_sigmoid', return_sequences=True))

#4model.add(MaxPooling1D(3))
#5model.add(Conv1D(128,3, activation='tanh'))

#model.add(Conv1D(128, 3, activation='relu'))
#6model.add(GlobalAveragePooling1D())
#model.add(Dropout(0.5))
#7model.add(Dense(50, activation='tanh'))

#model.compile(loss='categorical_crossentropy',
#              optimizer = 'Adamax',
#              metrics=['accuracy'])

model.fit(X_train, y_train , batch_size = 15 ,  nb_epoch  = 5 )
scores = model.evaluate( X_test , y_test ,  batch_size = 15 , verbose = 0 ) 
#model = Sequential()
#model.add(LSTM(8,input_shape=(360,3),activation='sigmoid', inner_activation='hard_sigmoid', return_sequences=True))
#model.add(Activation('sigmoid'))
#model.add(LSTM(16,activation='sigmoid', inner_activation='hard_sigmoid', return_sequences=False))
#model.add(Activation('sigmoid'))
#model.add(Dropout(0.2))
#model.add(Dense(21))
#model.add(Activation('softmax'))
#model.compile(loss='categorical_crossentropy', optimizer='adadelta')

#model.add(Embedding(total_words, embedding_vecor_length, input_length=max_sequence_length))
#model.add(LSTM(100))
#model.add(Dense(1, activation='sigmoid'))
#model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
#print(model.summary())
#model.fit(X_train, y_train, nb_epoch=5, batch_size=15)
# Final evaluation of the model
#scores = model.evaluate(X_test, y_test, verbose=0)
result=model.predict( X_test , batch_size = 15 )
print (result)
print (scores)