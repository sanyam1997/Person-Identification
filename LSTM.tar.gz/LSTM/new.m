 D = dir('/media/hp/Data/DL/code/eeg_data/train/*.txt');
 S = {D.name};
 Set1 = [];
 %  erty=size(D,1)

 for i = 1 : length(S)
%      Mat = [Mat ; dlmread(S(i,1).name)];
    tr = load(strcat('/media/hp/Data/DL/code/eeg_data/train/' , S{i}));
    Set1(i,:,:)= tr( 13:132 , : );
 end
 
 set1 = zeros( 400 , 14 ) ;
 for i = 1 : 400  
    for j = 1 : 14
        %a = j*8 - 7 ; 
        %b = j*8 ;
        %for k = a : b
            %set1( i , j , 1:14 ) = mean( Set1( i , a:b , : ) ) ; 
            set1( i , j ) = std( Set1( i , : , j ) ) ; 
            
        %end
    end
 end
 
 E = dir('/media/hp/Data/DL/code/eeg_data/test/*.txt');
 F = { E.name } ;
 Set2 = [] ;
 for i = 1 : length(F)
%      Mat = [Mat ; dlmread(S(i,1).name)];
    tr = load(strcat('/media/hp/Data/DL/code/eeg_data/test/' , F{i}));
    Set2(i,:,:)= tr( 13:132 , : );
    
 end
 
 set2 = zeros( 100 , 14 ) ;
 for i = 1 : 100  
    for j = 1 : 14
        %a = j*2 - 1 ; 
        %b = j*2 ;
        %for k = a : b
            %set2( i , j , 1:14 ) = mean( Set2( i , a:b , : ) ) ; 
            set2( i , j ) = std( Set2( i , : , j ) ) ; 
            
        %end
    end
 end
 
 label3 = zeros( 60 , 480 ) ;
 
 for i = 1 : 60 
     a = 8*i - 7 ;
     b = 8*i ;
     for j = a : b
         label3( i , j ) = 1 ;
     end
 end
 
 label4 = zeros( 60 , 120 ) ;
 for i = 1 : 60
     a = 2*i - 1 ;
     b = 2*i ;
     for j = a : b
         label4( i , j ) = 1 ;
     end
 end
 
 label1 = zeros( 400  , 50 ) ;
 
 for i = 1 : 50
     a = 8*i - 7 ;
     b = 8*i ;
     for j = a : b 
         label1( j , i ) = i ;
     end
 end
     
 label2 = zeros( 100 , 1 ) ;
 
 for i =  1 : 50 
     a = 2*i - 1;
     b = 2*i ;
     for j = a : b
         label2( j ) = i ;
     end
 end
 
 Mat1 = zeros( 400 , 4 , 350 ) ;
 for i = 1 : 400 
     m1 = squeeze(Set1(i,:,:));
     for j=1:4
         d1 = m1( ( j - 1 )*25 + 1 : j*25 , : ) ;
         Mat1(i,j,:) = d1(:) ; 
     end
 end
 Mat2 = zeros( 100 , 4 , 350 ) ;
 for i = 1 : 100 
     m2 = squeeze(Set2(i,:,:));
     for j=1:4
         d2 = m2( ( j - 1 )*25 + 1 : j*25 , : ) ;
         Mat2(i,j,:) = d2(:) ; 
     end
 end 
 
 Mat3 = zeros( 400 , 14 ) ;
 
 %for i = 1 : 400
    %p = 1 ;
     %for j = 1 : 15
  %       for k = 1 : 14
   %          Mat3( i , k ) = set1( i , 1 , k ) ;
             %p = p + 1 ;
    %     end
     %end
 %end
 
Mat4 = zeros( 100 , 14 ) ;

%for i = 1 : 100
    %p = 1 ;
     %for j = 1 : 15
 %        for k = 1 : 14
  %           Mat4( i , k ) = set2( i , 1 , k ) ;
             %p = p + 1 ;
   %      end
     %end
 %end 
 
 
 %Mat3 = reshape( Set1 , 400 , 1400 );
 %Mat4 = reshape( Set2 , 100 , 1400 ) ;
 %label3 = reshape( label1 , 20000 , 1 ) ;
 %label4 = reshape( label2 , 5000 , 1 ) ;
         
save('/media/hp/Data/DL/code/DataS5.mat','Set1' , 'set1' , 'Set2' , 'set2' ,'label1' , 'label2' , 'label3' , 'label4' ,  'Mat1' , 'Mat2' , 'Mat3' , 'Mat4' ,'-v7.3');
%save('Test.mat','data','label','-v7.3');